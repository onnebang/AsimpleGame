package hitesh.asimplegame;

public class Main {
}
